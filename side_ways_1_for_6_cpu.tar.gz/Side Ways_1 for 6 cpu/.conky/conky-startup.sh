#!/bin/bash

killall conky

conky -c ~/.conky/conkyrc_sideways-revisited_1 ;

exit 0
