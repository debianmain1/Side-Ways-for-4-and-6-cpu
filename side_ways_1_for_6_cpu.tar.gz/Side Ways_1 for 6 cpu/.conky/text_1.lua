--[[
Conky Widgets by londonali1010 (2009)
Modified By autocrosser (5-27-2019)

Call this script in Conky using the following before TEXT (assuming you save this script to ~/scripts/conky_widgets.lua):
	lua_load ~/Scripts/conky_widgets.lua
	lua_draw_hook_pre load_text ]]

require 'cairo'
function draw_text()
	if conky_window==nil then return end
	local w=conky_window.width
	local h=conky_window.height
	local cs=cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, w, h)
	cr=cairo_create(cs)
		
-- Font
cairo_select_font_face (cr, "Astrud", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);

-- font size
cairo_set_font_size (cr, 60.0);

--font color
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 1);

cairo_translate (cr, -0.0, 0.0);
-- angle
cairo_rotate(cr,-0.52);

-- text position
cairo_move_to (cr, 690.0, 590.0);

-- shown text
cairo_show_text (cr, conky_parse('${execi 3600 /bin/cat /etc/*release* | grep PRETTY_NAME | cut -c 14-29}'));

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 920.0, 665.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${cpu cpu1}%'));

cairo_set_font_size (cr, 65.0);
cairo_move_to (cr, 840.0, 665.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'CPU1');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 720.0, 735.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${cpu cpu3}%'));

cairo_set_font_size (cr, 65.0);
cairo_move_to (cr, 630.0, 735.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'CPU3');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 760.0, 665.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${cpu cpu2}%'));

cairo_set_font_size (cr, 65.0);
cairo_move_to (cr, 670.0, 665.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'CPU2');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 900.0, 735.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${cpu cpu4}%'));

cairo_set_font_size (cr, 65.0);
cairo_move_to (cr, 810.0, 735.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'CPU4');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 700.0, 815.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${cpu cpu5}%'));

cairo_set_font_size (cr, 65.0);
cairo_move_to (cr, 600.0, 815.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'CPU5');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 870.0, 815.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${cpu cpu6}%'));

cairo_set_font_size (cr, 65.0);
cairo_move_to (cr, 780.0, 815.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'CPU6');

cairo_set_font_size (cr, 60.0);
cairo_move_to (cr, 570.0, 890.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'RAM');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 620.0, 940.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('$mem/$memmax'));

cairo_set_font_size (cr, 55.0);
cairo_move_to (cr, 530.0, 990.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'ROOT');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 580.0, 1040.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${fs_used /}'));

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 670.0, 1040.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, 'of');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 700.0, 1040.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${fs_free /}'));

cairo_set_font_size (cr, 55.0);
cairo_move_to (cr, 480.0, 1100.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'HOME');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 510.0, 1150.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${fs_used /home}'));

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 600.0, 1150.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, 'of');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 630.0, 1150.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${fs_free /home}'));

cairo_set_font_size (cr, 55.0);
cairo_move_to (cr, 440.0, 1210.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'UPLOAD');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 500.0, 1250.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${upspeed bond0} kb/s'));

cairo_set_font_size (cr, 55.0);
cairo_move_to (cr, 400.0, 1300.0);
cairo_set_source_rgba (cr, 0.325490196, 0.258823529, 0.035294118, 0.2);
cairo_show_text (cr, 'DOWNLOAD');

cairo_set_font_size (cr, 40.0);
cairo_move_to (cr, 470.0, 1340.0);
cairo_set_source_rgba (cr, 0.192156863, 0.180392157, 0.156862745, 0.7);
cairo_show_text (cr, conky_parse('${downspeed bond0} kb/s'));

cairo_stroke (cr);

end

function conky_load_text()
 if conky_window==nil then return end
    local cs=cairo_xlib_surface_create(conky_window.display,conky_window.drawable,conky_window.visual, conky_window.width,conky_window.height)
    
    local cr=cairo_create(cs)    
    
    local updates=conky_parse('${updates}')
    update_num=tonumber(updates)
    
    if update_num>5 then
       draw_text()
    end
end

