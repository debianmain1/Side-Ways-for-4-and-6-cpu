Conky Sideways Revisited

To install just copy the "conky" to your hidden ".conky" folder in your user/home folder!

Don't forget to install the "fonts" to ".fonts"!

to run, execute ' conky-startup.sh '

To enable conky to start with the system go to " startup applications " and add in the " command " the file " .conky/conky-startup.sh "

  

