#!/bin/bash

killall conky

conky -c ~/.conky/conkyrc_sideways-revisited ;

exit 0
